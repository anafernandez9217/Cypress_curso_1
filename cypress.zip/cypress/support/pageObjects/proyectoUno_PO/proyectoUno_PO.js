import ProyectoUno_Po from '../../../support/pageObjects/proyectoUno_PO/proyectoUno_PO'

class ProyectoUno_Po{

    visiHome(){
        let tiempo=1000
        before(()=>{
            cy.visit('https://validaciones.rodrigovillanueva.com.mx/Campos_Dos_OK.html'),
            cy.title().should('eq','Formulario de Ejemplo')
            cy.wait(tiempo)
        })
    }

}//final

export default ProyectoUno_Po;
/// <reference types="Cypress" />

require('cypress-xpath')

describe("Nueva sección Select ", () =>{
    it("Select uno ", () =>{
        cy.visit("https://testsheepnz.github.io/panther-build5.html#calculator ")
        cy.wait(2000)

        cy.get("#numMissiles").should("be.visible").select("2")
        cy.wait(2000)
        cy.get("#numMissiles").should("be.visible").select("4").should("have.value","4")

    })

    it.only("Index principal ", () =>{
        let time= 2000;
        let timeLong= 5000;
        cy.visit("https://dev3.mexrentacar.com/es/index ")
        cy.title().should('eq','Renta de autos en México, Estados Unidos y otros destinos - Mex Rent a Car')
        cy.wait(time)
        //cy.get("#numMissiles").should("be.visible").select("4").should("have.value","4")
        cy.get('#rez-form-wrapper > form > div:nth-child(1) > div > div:nth-child(2) > input').should("be.visible").type('GDL - Guadalajara Aeropuerto, Guadalajara, Jalisco, México')
        cy.get('#react-autowhatever-autosuggest_pickup-section-0-item-0 > :nth-child(2)').should("be.visible").click()
        cy.wait(time)
  
        // Intentando cambiar horario //
        //cy.get("span").should("be.visible").select("9:00 am")
        //cy.get("[type='i']").should("contain","9:00 am")
        //cy.get('#btn-timepicker > span').should("be.visible").select("01:00 pm")
        //cy.get('li').eq(2).should('be.visible').click() // 

        // Seleccionar intervalo de fechas
        cy.get('[aria-label="Choose Tuesday, March 4, 2025 as your check-in date. It’s available."]').should("be.visible").click()
        cy.wait(time)
        cy.get('[aria-label="Choose Saturday, March 8, 2025 as your check-out date. It’s available."]').should("be.visible").click()
        cy.wait(time)
        cy.get('.wrapper-mex-form-input-btn > .ml-auto').should("be.visible").click()
        cy.wait(timeLong)
        cy.get('#card_3 > [style="overflow: hidden;"] > .car-card-content > [style="grid-area: c;"] > .img-car').should("be.visible").click()
        cy.wait(time)

        // Elegir los adicionales
        cy.get(':nth-child(3) > [style="display: flex; flex-direction: column; overflow: hidden;"] > .additional-item-main').should("be.visible").click()
        cy.wait(time)
        cy.get('#additional-item-total > .btn-confirm').should("be.visible").click()
        cy.wait(time)

        // Pantalla de información del lado izquierdo
        cy.get('#client-firstname').should("be.visible").type('Arturo')
        cy.get(':nth-child(2) > .mx-2').should("be.visible").type('Navidad')
        cy.get(':nth-child(3) > .mx-2').should("be.visible").type('navidad_a@gmail.com')
        cy.wait(time)
        cy.get(':nth-child(4) > .mx-4 > .check-custom').should("be.visible").click()
        cy.wait(timeLong)

        // Pantalla de información del lado derecho
        cy.get('.form-control').should("be.visible").type('3311777082')
        cy.get('.d-flex > .mx-4 > .check-custom').should("be.visible").click()
        cy.wait(time)
        cy.get(':nth-child(4) > .mx-2').should("be.visible").type('R0004772')
        cy.get('.mt-5 > :nth-child(2) > :nth-child(5)').should("be.visible").type('México')
        cy.get(':nth-child(6) > .mx-2').should("be.visible").type('Jalisco')
        cy.wait(time)
        cy.get(':nth-child(7) > .mx-2').should("be.visible").type('A8737')
        cy.get(':nth-child(8) > .mx-2').should("be.visible").type('Aeromexico')
        cy.get('.form-textarea-client-control > .mx-2').should("be.visible").type('El cliente llega de abordar vuelo internacional preveniente de California y acude a la renta de la unidad.')
        cy.wait(time)

        // Envio de Input final: btn-confirm
        //cy.get(':nth-child(11) > .btn-confirm').should("be.visible").click()
        cy.get(':nth-child(11) > .btn-confirm').should( 'exist')
  
    })

})

/// <reference types='Cypress' />

import 'cypress-file-upload';
import ProyectoUno_Po from '../../support/pageObjects/proyectoUno_PO/proyectoUno_PO';
require('@4tw/cypress-drag-drop')
require('cypress-xpath')
require('cypress-plugin-tab')


describe('Page objects Models', () =>{ 

    // Podemos usar las funciones contenidas en el archivo que importamos
    const master=new ProyectoUno_Po()

    master.visiHome

    Cypress.on('uncaught:exception', (err, runnable)=> {
        return false
    })
    
    /*
    let tiempo=1000
    before(() => {  
        cy.visit('Url'),
        cy.title().should('eq','titulo')
        cy.wait(tiempo)
    })*/

    it('Test uno', () =>{
        cy.log("hola")
    })
});
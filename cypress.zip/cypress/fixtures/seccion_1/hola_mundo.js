describe("Bienvenido al curso de Cypress sección 1", () =>{

    it("Mi primer Test -> Hola mundo", () =>{
        cy.log("Hola mundo")// para imprimir en pantalla
    
    })

})//Cierre de describe

